// ═══════════════════════════════════════
// src/pages/LandingPage.jsx
// ═══════════════════════════════════════

import { useNavigate } from 'react-router-dom';
import './LandingPage.css';

const PRODUCTOS = [

  {
    icon:'💰',
    titulo:'Cuenta de Ahorros',
    desc:'Ahorra tu dinero de forma segura y rápida.'
  },

  {
    icon:'💳',
    titulo:'Tarjetas',
    desc:'Compra en línea y en tiendas con total seguridad.'
  },

  {
    icon:'🏦',
    titulo:'Créditos',
    desc:'Solicita préstamos y créditos personales fácilmente.'
  },

  {
    icon:'📱',
    titulo:'Banca Digital',
    desc:'Realiza operaciones desde cualquier lugar.'
  }

];

export default function LandingPage(){

  const navigate = useNavigate();

  return(

    <div className="fade-up">

      {/* ── NAVBAR ── */}

      <nav className="navbar">

        <div className="nav-logo">

          <img
            src="/maynas.png"
            alt="CMAC Maynas"
            style={{
              height:'55px'
            }}
          />

          <span className="logo-text">
            CMAC Maynas
          </span>

        </div>

        <div className="nav-links">

          <button className="nav-link">
            Créditos
          </button>

          <button className="nav-link">
            Ahorros
          </button>

          <button className="nav-link">
            Seguros
          </button>

          <button className="nav-link">
            Agencias
          </button>

          <button
            className="btn btn-red"
            onClick={() => navigate('/login')}
          >
            Banca por Internet
          </button>

        </div>

      </nav>

      {/* ── HERO ── */}

      <section className="hero">

  <div className="hero-inner">

    <div className="hero-left">

      <div className="hero-badge">
        ⭐ Caja Municipal del Perú
      </div>

      <h1>
        Tu caja digital
        <br/>
        siempre contigo
      </h1>

      <p>
        Gestiona tus cuentas, transfiere dinero
        y paga tus servicios desde cualquier lugar
        del país de manera rápida y segura.
      </p>

      <div className="hero-ctas">

        <button
          className="btn btn-white"
          onClick={() => navigate('/login')}
        >
          Ingresar a mi cuenta
        </button>

        <button className="btn btn-ghost">
          Conocer más
        </button>

      </div>

      <div className="hero-stats">

        <div>

          <div className="stat-num">
            +1M
          </div>

          <div className="stat-label">
            Clientes en el Perú
          </div>

        </div>

        <div>

          <div className="stat-num">
            24/7
          </div>

          <div className="stat-label">
            Atención digital
          </div>

        </div>

        <div>

          <div className="stat-num">
            100%
          </div>

          <div className="stat-label">
            Operaciones seguras
          </div>

        </div>

      </div>

    </div>


    <div className="hero-image">

<img
src="https://images.unsplash.com/photo-1563013544-824ae1b704d3?q=80&w=1000"
alt="Banca digital"
/>

</div>

  </div>

</section>

      {/* ── PRODUCTOS ── */}

      <section className="products">

        <div className="section-header">

          <h2>
            Nuestros Productos
          </h2>

          <p>
            Servicios financieros para ti
          </p>

        </div>

        <div className="products-grid">

          {PRODUCTOS.map((p) => (

            <div
              key={p.titulo}
              className="product-card"
            >

              <div className="product-icon">
                {p.icon}
              </div>

              <h3>
                {p.titulo}
              </h3>

              <p>
                {p.desc}
              </p>

            </div>

          ))}

        </div>

      </section>

      {/* ── PROMO ── */}

      <div className="promo-banner">

        <h2>
          Abre tu cuenta hoy
        </h2>

        <p>
          Empieza a disfrutar de todos
          nuestros beneficios digitales.
        </p>

        <button className="btn btn-white">
          Crear Cuenta
        </button>

      </div>

      {/* ── FOOTER ── */}

      <footer className="landing-footer">

        <strong>
          CMAC Maynas
        </strong>

        <br />

        Caja Municipal de Ahorro y Crédito

        <br />

        © 2026 Todos los derechos reservados

      </footer>

    </div>

  );

}