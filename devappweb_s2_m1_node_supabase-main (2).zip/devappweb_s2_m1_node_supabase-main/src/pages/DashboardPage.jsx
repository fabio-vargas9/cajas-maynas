// ═══════════════════════════════════════
// src/pages/DashboardPage.jsx
// ═══════════════════════════════════════

import { useNavigate } from 'react-router-dom';

import {
  obtenerSesion,
  cerrarSesion
}
from '../services/authService';

import './DashboardPage.css';

/* movimientos */

const MOVIMIENTOS = [

  {
    icon:'💸',
    nombre:'Transferencia enviada',
    fecha:'Hoy - 10:30 AM',
    monto:'- S/ 250.00',
    tipo:'negative'
  },

  {
    icon:'💰',
    nombre:'Depósito recibido',
    fecha:'Ayer - 03:20 PM',
    monto:'+ S/ 1,200.00',
    tipo:'positive'
  },

  {
    icon:'🛒',
    nombre:'Pago en supermercado',
    fecha:'Ayer - 07:15 PM',
    monto:'- S/ 89.90',
    tipo:'negative'
  },

  {
    icon:'📱',
    nombre:'Pago de servicio',
    fecha:'12 Mayo - 09:00 AM',
    monto:'- S/ 45.00',
    tipo:'negative'
  }

];

export default function DashboardPage(){

  const navigate = useNavigate();

  const sesion = obtenerSesion();

  /* logout */

  function handleLogout(){

    cerrarSesion();

    navigate('/');

  }

  return(

    <div className="dashboard-page fade-up">

      {/* ── NAVBAR ── */}

      <nav className="dash-nav">

        <div className="dash-nav-left">

          <div className="dash-avatar">

            {
              sesion?.nombre
              ?
              sesion.nombre[0]
              :
              'U'
            }

          </div>

          <div>

            <div className="dash-user-name">

              {
                sesion?.nombre
                ?
                sesion.nombre
                :
                'Usuario'
              }

            </div>

            <div className="dash-user-email">

              {
                sesion?.email
                ?
                sesion.email
                :
                'correo@gmail.com'
              }

            </div>

          </div>

        </div>

        <button
          className="btn-logout"
          onClick={handleLogout}
        >
          Cerrar sesión
        </button>

      </nav>

      {/* ── BODY ── */}

      <div className="dash-body">

        {/* saludo */}

        <div className="dash-greeting">

          <h1>
            Bienvenido 👋
          </h1>

          <p>
            Este es tu panel principal de CMAC Maynas
          </p>

        </div>

        {/* tarjetas */}

        <div className="cards-row">

          <div className="balance-card">

            <div className="card-label">
              Saldo Disponible
            </div>

            <div className="card-amount">
              S/ 12,580.00
            </div>

            <div className="card-sub">
              Cuenta de ahorros
            </div>

          </div>

          <div className="balance-card">

            <div className="card-label">
              Créditos
            </div>

            <div className="card-amount">
              S/ 8,200.00
            </div>

            <div className="card-sub">
              Crédito personal activo
            </div>

          </div>

          <div className="balance-card">

            <div className="card-label">
              Tarjetas
            </div>

            <div className="card-amount">
              S/ 3,450.00
            </div>

            <div className="card-sub">
              Línea disponible
            </div>

          </div>

        </div>

        {/* grid */}

        <div className="dash-grid">

          {/* movimientos */}

          <div className="panel">

            <div className="panel-title">
              Últimos movimientos
            </div>

            <div className="tx-list">

              {MOVIMIENTOS.map((m) => (

                <div
                  className="tx-item"
                  key={m.nombre}
                >

                  <div className="tx-icon">
                    {m.icon}
                  </div>

                  <div className="tx-info">

                    <div className="tx-name">
                      {m.nombre}
                    </div>

                    <div className="tx-date">
                      {m.fecha}
                    </div>

                  </div>

                  <div
                    className={
                      `tx-amount ${m.tipo}`
                    }
                  >

                    {m.monto}

                  </div>

                </div>

              ))}

            </div>

          </div>

          {/* derecha */}

          <div>

            {/* acciones */}

            <div className="panel">

              <div className="panel-title">
                Acciones rápidas
              </div>

              <div className="quick-actions">

                <button className="action-btn">

                  <div className="action-icon">
                    💸
                  </div>

                  <div className="action-label">
                    Transferir
                  </div>

                </button>

                <button className="action-btn">

                  <div className="action-icon">
                    💳
                  </div>

                  <div className="action-label">
                    Pagar
                  </div>

                </button>

                <button className="action-btn">

                  <div className="action-icon">
                    📱
                  </div>

                  <div className="action-label">
                    Recargas
                  </div>

                </button>

                <button className="action-btn">

                  <div className="action-icon">
                    🏦
                  </div>

                  <div className="action-label">
                    Créditos
                  </div>

                </button>

              </div>

            </div>

            {/* próximamente */}

            <div className="coming-soon">

              🚀 Próximamente nuevas funciones
              y mejoras para tu banca digital.

            </div>

          </div>

        </div>

      </div>

    </div>

  );

}