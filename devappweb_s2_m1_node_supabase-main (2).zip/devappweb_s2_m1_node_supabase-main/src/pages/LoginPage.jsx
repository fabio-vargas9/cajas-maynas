// ═══════════════════════════════════════
// src/pages/LoginPage.jsx
// ═══════════════════════════════════════

import { useState } from 'react';

import { useNavigate } from 'react-router-dom';

import {
  login,
  guardarSesion
}
from '../services/authService';

import './LoginPage.css';

/* características */

const FEATURES = [

  'Transferencias rápidas y seguras',

  'Consulta de saldos y movimientos',

  'Pago de servicios en línea',

  'Acceso las 24 horas del día',

  'Seguridad y protección de datos'

];

export default function LoginPage(){

  const navigate = useNavigate();

  const [email,setEmail] = useState('');

  const [password,setPassword] = useState('');

  const [error,setError] = useState('');

  const [cargando,setCargando] = useState(false);

  /* submit */

  async function handleSubmit(e){

    e.preventDefault();

    setError('');

    /* validar */

    if(!email || !password){

      setError('Completa todos los campos');

      return;
    }

    setCargando(true);

    try{

      const data = await login(email,password);

      guardarSesion(
        data.token,
        data.user
      );

      navigate('/dashboard');

    }catch(err){

      setError(
        'Error al iniciar sesión'
      );

    }finally{

      setCargando(false);
    }

  }

  return(

    <div
      className="fade-up"
      id="loginPage"
    >

      {/* ── NAVBAR ── */}

      <nav className="navbar">

        <div
          className="nav-logo"
          onClick={() => navigate('/')}
          style={{cursor:'pointer'}}
        >

          <img
            src="/maynas.png"
            alt="CMAC Maynas"
            style={{
              height:'55px'
            }}
          />

          <span className="logo-text">
            CMAC <span>Maynas</span>
          </span>

        </div>

        <div className="nav-links">

          <button
            className="nav-link"
            onClick={() => navigate('/')}
          >
            ← Volver
          </button>

        </div>

      </nav>

      {/* ── layout ── */}

      <div className="login-layout">

        {/* izquierda */}

        <div className="login-left">

          <h2>
            Bienvenido
            <br />
            a CMAC Maynas
          </h2>

          <p>
            Accede a tu cuenta y realiza
            operaciones de manera rápida,
            moderna y segura desde cualquier lugar.
          </p>

          <ul className="login-features">

            {FEATURES.map((f) => (

              <li key={f}>

                <div className="feature-check">
                  ✓
                </div>

                {f}

              </li>

            ))}

          </ul>

        </div>

        {/* derecha */}

        <div className="login-right">

          <div className="login-card">

            <div className="login-card-header">

              <h3>
                Iniciar Sesión
              </h3>

              <p>
                Ingresa tus datos para continuar
              </p>

            </div>

            {/* error */}

            {error && (

              <div className="error-msg">
                ⚠ {error}
              </div>

            )}

            {/* formulario */}

            <form onSubmit={handleSubmit}>

              <div className="form-group">

                <label>
                  Correo electrónico
                </label>

                <input
                  type="email"
                  placeholder="correo@gmail.com"
                  value={email}
                  onChange={(e)=>
                    setEmail(e.target.value)
                  }
                />

              </div>

              <div className="form-group">

                <label>
                  Contraseña
                </label>

                <input
                  type="password"
                  placeholder="********"
                  value={password}
                  onChange={(e)=>
                    setPassword(e.target.value)
                  }
                />

              </div>

              <button
                type="submit"
                className="btn-login"
                disabled={cargando}
              >

                {
                  cargando
                  ?
                  'Ingresando...'
                  :
                  'Ingresar'
                }

              </button>

            </form>

            <p className="login-footer-text">

              ¿Problemas para ingresar?

              <a href="#">
                Contáctanos
              </a>

            </p>

          </div>

        </div>

      </div>

    </div>

  );

}